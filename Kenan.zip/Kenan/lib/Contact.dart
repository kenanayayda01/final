class Contact {
  String name,phone;

  Contact({required this.name,required this.phone});



  @override
  String toString() {
    return '''
    name: $name 
    phone: $phone
    ''';
  }
}