import 'package:flutter/material.dart';
import 'Contact.dart';

class ContactModel extends ChangeNotifier{
  List<Contact> contacts= [];
  int _selectedContact = 0;
  void addContact(Contact contact){
    contacts.add(contact);
    notifyListeners();
  }



  set selectedContact(int value) {
    _selectedContact = value;
  }

  void removeContact (){
    contacts.removeAt(_selectedContact);
    notifyListeners();
  }
  void updateContact (Contact contact){
    contacts[_selectedContact]=contact;
    notifyListeners();
  }
}