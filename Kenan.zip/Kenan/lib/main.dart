import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ContactModel.dart';
import 'addContact.dart';
import 'updateContact.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) =>ContactModel(),
      child: MaterialApp(
        routes:{
          '/':(context) => MyHomePage(),
          '/add':(context) =>addContact(),
          '/update':(context) => updateContact(),
        } ,

        theme: ThemeData(

          primarySwatch: Colors.blue,
        ),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage();

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    _showDialog(BuildContext context,String Details) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
              scrollable: true,
              title: Text('Product Info'),
              content:Text(Details),
            actions: [
              TextButton(onPressed:(){
                Navigator.of(context).pop();
                setState(() {

                });
              } , child: Text("cancel"))

            ],
            ),

        );
           }

    return Consumer<ContactModel>(
      builder: (BuildContext context, value, Widget? child) {
        return Scaffold(
          appBar: AppBar(

            title: Text("Contact"),
          ),
          body: Center(
            child: ListView.builder(
                itemCount: value.contacts.length,
                itemBuilder: (context ,index){
                  return ListTile(
                    leading: Text(value.contacts[index].name.substring(0,1)),
                    title:Text(value.contacts[index].name) ,
                    trailing: IconButton(onPressed: (){
                      value.selectedContact =index;
                      value.removeContact();
                    }, icon: Icon(Icons.delete)),
                    onTap: (){
                      _showDialog(context,value.contacts[index].toString());
                     // _showDialog(context, "${value.contacts[index].phone},${value.contacts[index].name}");

                    },
                    onLongPress: (){
                      Navigator.pushNamed(context,'/update');
                    },
                  );
                }
            ),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              Navigator.pushNamed(context, '/add');
              setState(() {

              });
            },

            child: const Icon(Icons.add),
          ), // This trailing comma makes auto-formatting nicer for build methods.
        );

      },

    );
  }
}






