import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Contact.dart';
import 'ContactModel.dart';

class addContact extends StatefulWidget {
  @override
  State<addContact> createState() => _addContactState();
}

class _addContactState extends State<addContact> {
  TextEditingController nameController = TextEditingController();

  TextEditingController phoneController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Consumer<ContactModel>(
        builder: (BuildContext context, value, Widget? child) {
          return Scaffold(
            appBar: AppBar(title: Text("add"),),
            body: Padding(
              padding: EdgeInsets.all(8),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: nameController,

                      decoration: InputDecoration.collapsed(
                          hintText: 'name'
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: phoneController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration.collapsed(
                          hintText: 'phone'
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      TextButton(onPressed: () {
                        value.contacts.add(Contact(name: nameController.text,
                            phone: phoneController.text));
                        setState(() {
                          nameController.clear();
                          phoneController.clear();
                        });
                      }, child: Text("add")),
                      TextButton(onPressed: () {
                        Navigator.pushNamed(context, '/');
                      }, child: Text("cancel")),
                    ],
                  )
                ],
              ),
            ),
          );
        }


    );
  }
}