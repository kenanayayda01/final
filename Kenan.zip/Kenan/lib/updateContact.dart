import 'package:flutter/cupertino.dart';

class updateContact extends StatefulWidget {
  const updateContact({Key? key}) : super(key: key);

  @override
  State<updateContact> createState() => _updateContactState();
}

class _updateContactState extends State<updateContact> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
